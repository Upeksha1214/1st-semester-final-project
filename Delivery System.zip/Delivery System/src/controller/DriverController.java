package controller;

import Db.DbConnection;
import animatefx.animation.Pulse;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Driver;
import model.Employee;
import view.TM.DriverTm;
import view.TM.EmployeeTm;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DriverController implements DriverService{
    public Pane homePane;
    public Pane addPane;
    public Pane searchPane;
    public Pane updatePane;
    public Pane deletePane;
    public AnchorPane driverContext;
    public AnchorPane driverControllerContext;

    private void clearPane(){
        homePane.setStyle("-fx-background-color: #E8ADAA");
        addPane.setStyle("-fx-background-color: #52D017");
        searchPane.setStyle("-fx-background-color: #357EC7");
        updatePane.setStyle("-fx-background-color: #F2BB66");
        deletePane.setStyle("-fx-background-color:  #cb6d51");
    }

    public void homeMouseOnAction(MouseEvent mouseEvent) throws IOException {
        clearPane();
        homePane.setStyle("-fx-background-color:#8D3DAF");

        Stage window = (Stage) driverContext.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/StoreKeeper.fxml"))));
    }

    public void homeMouseEnteredOnAction(MouseEvent mouseEvent) {
        clearPane();
        new Pulse(homePane).play();
        homePane.setStyle("-fx-background-color: #E8ADAA");
    }

    public void addDriverMouseOnAction(MouseEvent mouseEvent) throws IOException {
        clearPane();
        addPane.setStyle("-fx-background-color:#ccfb5d");

        URL resource = getClass().getResource("../view/DriverAdd.fxml");
        Parent load = FXMLLoader.load(resource);
        driverControllerContext.getChildren().add(load);
    }

    public void addDriverEnteredOnaction(MouseEvent mouseEvent) {
        clearPane();
        new Pulse(addPane).play();
        addPane.setStyle("-fx-background-color: #52D017");
    }


    public void searchDriverMoseOnAction(MouseEvent mouseEvent) throws IOException {
        clearPane();
        searchPane.setStyle("-fx-background-color:#ccfb5d");

        URL resource = getClass().getResource("../view/DriverSearch.fxml");
        Parent load = FXMLLoader.load(resource);
        driverControllerContext.getChildren().add(load);
    }

    public void searchMouseEnteredOnAction(MouseEvent mouseEvent) {
        clearPane();
        new Pulse(searchPane).play();
        searchPane.setStyle("-fx-background-color: #357EC7");
    }


    public void updateDriverMouseOnAction(MouseEvent mouseEvent) throws IOException {
        clearPane();
        updatePane.setStyle("-fx-background-color:#ccfb5d");

        URL resource = getClass().getResource("../view/DriverUpdate.fxml");
        Parent load = FXMLLoader.load(resource);
        driverControllerContext.getChildren().add(load);
    }

    public void updateDriverMouseEnteredOnAction(MouseEvent mouseEvent) {
        clearPane();
        new Pulse(updatePane).play();
        updatePane.setStyle("-fx-background-color: #F2BB66");
    }

    public void deleteDriverMouseOnAction(MouseEvent mouseEvent) throws IOException {
        clearPane();
        deletePane.setStyle("-fx-background-color:#ccfb5d");

        URL resource = getClass().getResource("../view/DriverDelete.fxml");
        Parent load = FXMLLoader.load(resource);
        driverControllerContext.getChildren().add(load);
    }

    public void deleteDriverMoseEnteredOnAction(MouseEvent mouseEvent) {
        clearPane();
        new Pulse(deletePane).play();
        deletePane.setStyle("-fx-background-color:  #cb6d51");
    }

    @Override
    public boolean driverAdd(Driver d) throws SQLException, ClassNotFoundException {

        Connection con = DbConnection.getInstance().getConnection();
        String query="INSERT INTO driver Values(?,?,?,?,?)";
        PreparedStatement stm = con.prepareStatement(query);
        stm.setObject(1,d.getDriverId());
        stm.setObject(2,d.getDriverNIC());
        stm.setObject(3,d.getDriverName());
        stm.setObject(4,d.getDriverAddress());
        stm.setObject(5,d.getDriverPhoneNumber());
        return stm.executeUpdate()>0;

    }

    @Override
    public String getNewDriverId() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT driverID FROM driver ORDER BY driverID DESC LIMIT 1");
        ResultSet resultSet = stm.executeQuery();

            String id = null;
            while (resultSet.next()) {
                String s = resultSet.getString(1);
                int tempId = Integer.parseInt(s.substring(1, 4));
                tempId = ++tempId;

                if (tempId < 10) {
                    id = "D00" + tempId;

                } else if (tempId >= 10 & tempId < 100) {
                    id = "D0" + tempId;
                } else if (tempId > 100) {
                    id = "D" + tempId;
                }


            }
            return id == null ? "D001" : id;
        }


    @Override
    public String getDId() throws SQLException, ClassNotFoundException {
        PreparedStatement stm=DbConnection.getInstance().getConnection().prepareStatement("SELECT driverID FROM driver ORDER BY driverID DESC LIMIT 1");
        ResultSet resultSet = stm.executeQuery();

            return resultSet.getString(1);
        }


    @Override
    public Driver searchDriver(String Id) throws SQLException, ClassNotFoundException {

        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM driver WHERE driverID=?");
        stm.setObject(1,Id);

        ResultSet rst = stm.executeQuery();
        if (rst.next()){
            return new Driver(
                    rst.getString(1),
                    rst.getString(2),
                    rst.getString(3),
                    rst.getString(4),
                    rst.getString(5)
            );
        }else {

        }
        return null;
    }

    @Override
    public ArrayList<DriverTm> getDriver() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM driver");
        ResultSet resultSet = stm.executeQuery();
        ArrayList<DriverTm> driverList=new ArrayList();
        while(resultSet.next()){

            driverList.add(new DriverTm(resultSet.getString(1),resultSet.getString(2),resultSet.getString(3),resultSet.getString(4),resultSet.getString(5)));

        }

            return driverList;
        }


    @Override
    public boolean driverUpdate(Driver d) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement
                ("UPDATE driver SET driverNIC=?, driverName=?, driverAddress=?,driverPhoneNumber=? WHERE driverID=?");
        stm.setObject(1,d.getDriverNIC());
        stm.setObject(2,d.getDriverName());
        stm.setObject(3,d.getDriverAddress());
        stm.setObject(4,d.getDriverPhoneNumber());
        stm.setObject(5,d.getDriverId());

        return stm.executeUpdate()>0;
    }

    @Override
    public boolean driverDelete(String Id) throws SQLException, ClassNotFoundException {
        if (DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM driver WHERE driverID='"+Id+"'").executeUpdate()>0){
            return true;
        }else{
            return false;
        }

    }
}
