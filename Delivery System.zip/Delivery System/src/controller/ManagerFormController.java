package controller;

import animatefx.animation.BounceIn;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class ManagerFormController {
    public AnchorPane mangerFormContext;

    public void btnEmployeeOnAction(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) mangerFormContext.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/Employee.fxml"))));
    }

    public void btnStoreOnAction(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) mangerFormContext.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/Store.fxml"))));
    }

    public void btnSystemReportOnAction(ActionEvent actionEvent) {
       /* Stage window = (Stage) mangerFormContext.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/"))));*/
    }

    public void btnSalary(ActionEvent actionEvent) {
    }

    public void logoutOnAction(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) mangerFormContext.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/DashBoardForm.fxml"))));
    }
}
