package controller;

import com.sun.deploy.panel.JreFindDialog;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.UserAccount;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;

public class DashBoardFormController {
    public TextField txtUsernName;
    public PasswordField pswdPassword;
    public AnchorPane loginContext;

    public void btnLoginOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException, IOException {
        /*List<UserAccount> userAccountList = new UserAccountController().getAccount();
        if (txtUsernName.getText().isEmpty() | pswdPassword.getText().isEmpty()) {
            new Alert(Alert.AlertType.WARNING, "Input User Name or PassWord").show();
        } else {
            for (int i = 0; i < userAccountList.size(); i++) {
                if (userAccountList.get(i).getUserName().equals(txtUsernName.getText()) && userAccountList.get(i).getPassword().equals(pswdPassword.getText())) {
                    URL resource = getClass().getResource("../view/ManagerForm.fxml");
                    Parent load = FXMLLoader.load(resource);
                    Stage window = (Stage) loginContext.getScene().getWindow();
                    window.setScene(new Scene(load));
                    break;

                } else {
                    new Alert(Alert.AlertType.WARNING, "userName Or Password error").show();
                }
            }
        }*/
        if (txtUsernName.getText().equalsIgnoreCase("m") && pswdPassword.getText().equalsIgnoreCase("1")) {
            Stage window = (Stage) loginContext.getScene().getWindow();
            window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/ManagerForm.fxml"))));
        } else if (txtUsernName.getText().equalsIgnoreCase("s") && pswdPassword.getText().equalsIgnoreCase("1")) {
            Stage window = (Stage) loginContext.getScene().getWindow();
            window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/StoreKeeper.fxml"))));


        } else {
            new Alert(Alert.AlertType.WARNING, "Wrong Username or Password", ButtonType.CLOSE).show();

        }
    }
}
