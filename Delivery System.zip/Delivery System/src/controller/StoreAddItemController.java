package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Employee;
import model.Store;
import view.TM.DriverTm;
import view.TM.EmployeeTm;
import view.TM.StoreTm;

import java.sql.SQLException;
import java.util.List;

public class StoreAddItemController {
    public TextField txtQtyOnHand;
    public TextField txtUnitPrice;
    public TextField txtDescription;
    public TextField txtItemCode;
    public TextField txtDiscount;
    public TableView tblItemAdd;
    public TableColumn colItemCode;
    public TableColumn colDescription;
    public TableColumn colUnitPrice;
    public TableColumn colQtyOnHand;
    public TableColumn colDiscount;


    public void initialize(){

        List<StoreTm> storeTms = null;
        try {
            storeTms = new StoreController().getItem();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if (storeTms.isEmpty()){
            new Alert(Alert.AlertType.WARNING,"empty set").show();
        }

        try {
            txtItemCode.setText(new StoreController().getNewItemCode());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        try {
            ObservableList<StoreTm> list=FXCollections.observableArrayList(new StoreController().getItem());
            colItemCode.setCellValueFactory(new PropertyValueFactory<>("itemCode"));
            colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
            colUnitPrice.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));
            colQtyOnHand.setCellValueFactory(new PropertyValueFactory<>("qtyOnHand"));
            colDiscount.setCellValueFactory(new PropertyValueFactory<>("disconnect"));
            tblItemAdd.setItems(list);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    private void clearTextBox() {
        txtDescription.setText(null);
        txtUnitPrice.setText(null);
        txtQtyOnHand.setText(null);
        txtDiscount.setText(null);
    }

    public void btnAddItem(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        Store s = new Store(
                txtItemCode.getText(), txtDescription.getText(), txtUnitPrice.getText(),
                txtQtyOnHand.getText(), txtDiscount.getText()
        );

            new StoreController().itemAdd(s);
            new Alert(Alert.AlertType.CONFIRMATION, "Complete").show();
            tblItemAdd.setItems(null);
            tblItemAdd.setItems(FXCollections.observableArrayList(new StoreController().getItem()));


            clearTextBox();

            txtItemCode.setText(new StoreController().getNewItemCode());



    }

    public void btnCancleOnAction(ActionEvent actionEvent) {
        clearTextBox();
    }
}



