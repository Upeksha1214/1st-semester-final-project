package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class StoreKeeperController {


    public AnchorPane storeKeeperOnAction;

    public void driverOnAction(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) storeKeeperOnAction.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/Driver.fxml"))));
    }

    public void vehicleOnAction(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) storeKeeperOnAction.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/Vehicle.fxml"))));
    }

    public void refOnAction(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) storeKeeperOnAction.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/Ref.fxml"))));
    }

    public void shopOnAction(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) storeKeeperOnAction.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/Shop.fxml"))));
    }

    public void oderDetailsOnAction(ActionEvent actionEvent) {
        /*Stage window = (Stage) storeKeeperOnAction.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/"))));*/
    }

    public void logOutOnAction(ActionEvent actionEvent) throws IOException {
        Stage window = (Stage) storeKeeperOnAction.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/DashBoardForm.fxml"))));
    }
}
