package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Shop;
import model.Vehicle;
import view.TM.ShopTm;
import view.TM.VehicleTm;

import java.sql.SQLException;
import java.util.List;

public class ShopAddController {
    public TableView tblShopAdd;
    public TableColumn colShopId;
    public TableColumn colShopName;
    public TableColumn colPhoneNumber;
    public TableColumn colShopAddress;
    public TextField txtShopId;
    public TextField txtShopName;
    public TextField txtPhoneNumber;
    public TextField txtShopAddress;

    public void initialize() throws SQLException, ClassNotFoundException {
        txtShopId.setText(new ShopController().getNewShopId());

        List<ShopTm> shop=new ShopController().getShop();
        if (shop.isEmpty()){
            new Alert(Alert.AlertType.WARNING,"empty set").show();
        }

        ObservableList<ShopTm> list=FXCollections.observableArrayList(new ShopController().getShop());
        colShopId.setCellValueFactory(new PropertyValueFactory<>("shopId"));
        colShopName.setCellValueFactory(new PropertyValueFactory<>("shopName"));
        colPhoneNumber.setCellValueFactory(new PropertyValueFactory<>("shopPhoneNumber"));
        colShopAddress.setCellValueFactory(new PropertyValueFactory<>("shopAddress"));

        tblShopAdd.setItems(list);
    }

    public void btnCancelOnAction(ActionEvent actionEvent) {
        clearTextBox();
    }

    public void btnAddOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        Shop s= new Shop(
                txtShopId.getText(),txtShopName.getText(),txtPhoneNumber.getText(),
                txtShopAddress.getText()
        );
        new ShopController().shopAdd(s);
        new Alert(Alert.AlertType.CONFIRMATION,"Complete").show();
        tblShopAdd.setItems(null);
        tblShopAdd.setItems(FXCollections.observableArrayList(new ShopController().getShop()));

        clearTextBox();
        txtShopAddress.setText(new VehicleController().getNewVehicleId());
    }

    private void clearTextBox() {
        txtShopName.setText(null);
        txtPhoneNumber.setText(null);
        txtShopAddress.setText(null);
    }
}
