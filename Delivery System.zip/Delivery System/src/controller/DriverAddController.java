package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Driver;
import model.Employee;
import view.TM.DriverTm;
import view.TM.EmployeeTm;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DriverAddController {
    public TableView<DriverTm> tblDriverAdd;
    public TableColumn colDriverId;
    public TableColumn colDriverNic;
    public TableColumn colDriverName;
    public TableColumn colDriverAddress;
    public TableColumn colPhoneNumber;
    public TextField txtDriverId;
    public TextField txtDriverName;
    public TextField txtDriverNice;
    public TextField txtDriverAddress;
    public TextField txtDPhoneNumber;

    public void initialize(){



        try {
            txtDriverId.setText(new DriverController().getNewDriverId());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        try {

            List<DriverTm> driver = new DriverController().getDriver();
            if (driver.isEmpty()){
                new Alert(Alert.AlertType.WARNING,"empty set").show();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        try {
            ObservableList<DriverTm> list=FXCollections.observableArrayList(new DriverController().getDriver());
            colDriverId.setCellValueFactory(new PropertyValueFactory<>("driverId"));
            colDriverNic.setCellValueFactory(new PropertyValueFactory<>("driverNIC"));
            colDriverName.setCellValueFactory(new PropertyValueFactory<>("driverName"));
            colDriverAddress.setCellValueFactory(new PropertyValueFactory<>("driverAddress"));
            colPhoneNumber.setCellValueFactory(new PropertyValueFactory<>("contactNumber"));
            tblDriverAdd.setItems(list);


        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void btnAdd(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {

        Driver d = new Driver(
                txtDriverId.getText(), txtDriverNice.getText(), txtDriverName.getText(),
                txtDriverAddress.getText(), txtDPhoneNumber.getText()
        );

                new DriverController().driverAdd(d);
                new Alert(Alert.AlertType.CONFIRMATION, "Complete").show();
                tblDriverAdd.setItems(null);
                tblDriverAdd.setItems(FXCollections.observableArrayList(new DriverController().getDriver()));

                clearTextBox();
                txtDriverId.setText(new DriverController().getNewDriverId());


        }


    private void clearTextBox() {
        
        txtDriverNice.setText(null);
        txtDriverName.setText(null);
        txtDriverAddress.setText(null);
        txtDPhoneNumber.setText(null);
    }

    public void btnCancle(ActionEvent actionEvent) {
        clearTextBox();
    }
}
