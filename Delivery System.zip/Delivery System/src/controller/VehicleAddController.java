package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Driver;
import model.Vehicle;
import view.TM.DriverTm;
import view.TM.VehicleTm;

import java.sql.SQLException;
import java.util.List;

public class VehicleAddController {
    public TextField txtVehicleNumber;
    public TextField txtVehicleId;
    public TextField txtVehicleType;
    public TextField txtVehicleRent;
    public TableView tblVehicleAdd;
    public TableColumn colVehicleAdd;
    public TableColumn colVehicleNumber;
    public TableColumn colVehicleType;
    public TableColumn colVehicleRent;


    public void initialize(){

        try {
            txtVehicleId.setText(new VehicleController().getNewVehicleId());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        List<VehicleTm> vehicle = null;
        try {
            vehicle = new VehicleController().getVehicle();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if (vehicle.isEmpty()){
            new Alert(Alert.AlertType.WARNING,"empty set").show();
        }


        ObservableList<VehicleTm> list= null;
        try {
            list = FXCollections.observableArrayList(new VehicleController().getVehicle());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        colVehicleAdd.setCellValueFactory(new PropertyValueFactory<>("vehicleId"));
        colVehicleNumber.setCellValueFactory(new PropertyValueFactory<>("vehicleNumber"));
        colVehicleType.setCellValueFactory(new PropertyValueFactory<>("vehicleType"));
        colVehicleRent.setCellValueFactory(new PropertyValueFactory<>("vehicleRent"));

        tblVehicleAdd.setItems(list);
    }
    public void cancelOcAction(ActionEvent actionEvent) {
        clearTextBox();
    }

    public void addOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {

        Vehicle v= new Vehicle(
                txtVehicleId.getText(),txtVehicleNumber.getText(),txtVehicleType.getText(),
                txtVehicleRent.getText()
        );
        new VehicleController().vehicleAdd(v);
        new Alert(Alert.AlertType.CONFIRMATION,"Complete").show();
        tblVehicleAdd.setItems(null);
        tblVehicleAdd.setItems(FXCollections.observableArrayList(new VehicleController().getVehicle()));

        clearTextBox();
        txtVehicleId.setText(new VehicleController().getNewVehicleId());
    }

    private void clearTextBox() {
    txtVehicleNumber.setText(null);
    txtVehicleType.setText(null);
    txtVehicleRent.setText(null);
    }

}
