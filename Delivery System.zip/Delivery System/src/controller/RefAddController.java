package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Ref;
import model.Vehicle;
import view.TM.RefTm;
import view.TM.VehicleTm;

import java.sql.SQLException;
import java.util.List;

public class RefAddController {
    public TextField txtPhoneNumber;
    public TextField txtRefAddress;
    public TextField txtRefName;
    public TextField txtRefNic;
    public TextField txtRefId;
    public TableView tblAddRef;
    public TableColumn colRefId;
    public TableColumn colRefNic;
    public TableColumn colRefName;
    public TableColumn colRefAddress;
    public TableColumn colPhoneNumber;

    public void initialize(){

        try {
            txtRefId.setText(new RefController().getNewRefId());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        List<RefTm> ref= null;
        try {
            ref = new RefController().getRef();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if (ref.isEmpty()){
            new Alert(Alert.AlertType.WARNING,"empty set").show();
        }



        ObservableList<RefTm> list= null;
        try {
            list = FXCollections.observableArrayList(new RefController().getRef());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        colRefId.setCellValueFactory(new PropertyValueFactory<>("refID"));
        colRefNic.setCellValueFactory(new PropertyValueFactory<>("refNIC"));
        colRefName.setCellValueFactory(new PropertyValueFactory<>("refName"));
        colRefAddress.setCellValueFactory(new PropertyValueFactory<>("refAddress"));
        colPhoneNumber.setCellValueFactory(new PropertyValueFactory<>("refPhoneNumber"));

        tblAddRef.setItems(list);
    }

    public void btnCancelOnAction(ActionEvent actionEvent) {
        clearTextBox();
    }

    public void btnAddOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        Ref r= new Ref(
                txtRefId.getText(),txtRefNic.getText(),txtRefName.getText(),
                txtRefAddress.getText(),txtPhoneNumber.getText()
        );
        new RefController().refAdd(r);
        new Alert(Alert.AlertType.CONFIRMATION,"Complete").show();
        tblAddRef.setItems(null);
        tblAddRef.setItems(FXCollections.observableArrayList(new RefController().getRef()));

        clearTextBox();
        txtRefId.setText(new VehicleController().getNewVehicleId());
    }

    private void clearTextBox() {
        txtRefNic.setText(null);
        txtRefName.setText(null);
        txtRefAddress.setText(null);
        txtPhoneNumber.setText(null);
    }
}
