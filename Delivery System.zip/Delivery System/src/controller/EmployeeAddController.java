package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Employee;
import view.TM.DriverTm;
import view.TM.EmployeeTm;

import java.sql.SQLException;
import java.util.List;

public class EmployeeAddController {
    
    public TextField txtEmployeeTelNumber;
    public TextField txtEmployeeId;
    public TextField txtEmployeeType;
    public TextField txtEmployeeNic;
    public TextField txtEmployeeName;
    public TextField txtEmployeeAddress;
    public TextField txtEmployeeSalary;
    public TableView tblEmployeeAdd;
    public TableColumn colEmployeeId;
    public TableColumn colEmployeeType;
    public TableColumn colEmployeeNic;
    public TableColumn colEmployeeName;
    public TableColumn colEmployeeAddress;
    public TableColumn colEmPhoneNumber;
    public TableColumn colEmployeeSalary;

    public void initialize(){

        List<EmployeeTm> employeeTms = null;
        try {
            employeeTms = new EmployeeController().getEmployee();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException classNotFoundException) {
            classNotFoundException.printStackTrace();
        }
        if (employeeTms.isEmpty()){
            new Alert(Alert.AlertType.WARNING,"empty set").show();
        }

        try {
            txtEmployeeId.setText(new EmployeeController().getNewEmployeeId());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        try {
            ObservableList<EmployeeTm> list=FXCollections.observableArrayList(new EmployeeController().getEmployee());

            colEmployeeId.setCellValueFactory(new PropertyValueFactory<>("employeeId"));
            colEmployeeType.setCellValueFactory(new PropertyValueFactory<>("employeeType"));
            colEmployeeNic.setCellValueFactory(new PropertyValueFactory<>("employeeNIC"));
            colEmployeeName.setCellValueFactory(new PropertyValueFactory<>("employeeName"));
            colEmployeeAddress.setCellValueFactory(new PropertyValueFactory<>("employeeAddress"));
            colEmPhoneNumber.setCellValueFactory(new PropertyValueFactory<>("employeePhoneNumber"));
            colEmployeeSalary.setCellValueFactory(new PropertyValueFactory<>("employeeSalary"));
            tblEmployeeAdd.setItems(list);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    public void btnAddTable(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {

        Employee e = new Employee(
                txtEmployeeId.getText(), txtEmployeeType.getText(), txtEmployeeNic.getText(),
                txtEmployeeName.getText(), txtEmployeeAddress.getText(), txtEmployeeTelNumber.getText(),
                txtEmployeeSalary.getText()
        );



            new EmployeeController().employeeAdd(e);
            new Alert(Alert.AlertType.CONFIRMATION,"Complete").show();
            tblEmployeeAdd.setItems(null);
            tblEmployeeAdd.setItems(FXCollections.observableArrayList(new EmployeeController().getEmployee()));

            clearTextBox();

            txtEmployeeId.setText(new EmployeeController().getNewEmployeeId());






    }

    private void clearTextBox(){
        txtEmployeeType.setText(null);
        txtEmployeeNic.setText(null);
        txtEmployeeName.setText(null);
        txtEmployeeAddress.setText(null);
        txtEmployeeTelNumber.setText(null);
        txtEmployeeSalary.setText(null);
    }


    public void cancelOnAction(ActionEvent actionEvent) {
        clearTextBox();
    }
}
