package controller;

import model.UserAccount;

import java.sql.SQLException;
import java.util.List;

public interface UserAccountService {
    public List <UserAccount> getAccount() throws SQLException, ClassNotFoundException;
}
