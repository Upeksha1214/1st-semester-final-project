package controller;

import Db.DbConnection;
import animatefx.animation.Pulse;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Driver;
import model.Vehicle;
import view.TM.DriverTm;
import view.TM.VehicleTm;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VehicleController implements VehicleService{
    public Pane homePane;
    public Pane addPane;
    public Pane searchPane;
    public Pane updatePane;
    public Pane deletePane;
    public AnchorPane vehicleContext;
    public AnchorPane vehicleControllerContext;

    private void clearPane(){
        homePane.setStyle("-fx-background-color: #E8ADAA");
        addPane.setStyle("-fx-background-color: #52D017");
        searchPane.setStyle("-fx-background-color: #357EC7");
        updatePane.setStyle("-fx-background-color: #F2BB66");
        deletePane.setStyle("-fx-background-color:  #cb6d51");
    }

    public void homeMouseOnAction(MouseEvent mouseEvent) throws IOException {
        clearPane();
        homePane.setStyle("-fx-background-color:#8D3DAF");

        Stage window = (Stage) vehicleContext.getScene().getWindow();
        window.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/StoreKeeper.fxml"))));
    }

    public void homeEnteredOnAction(MouseEvent mouseEvent) {
        clearPane();
        new Pulse(homePane).play();
        homePane.setStyle("-fx-background-color: #E8ADAA");
    }

    public void addVehicleMouseOnAction(MouseEvent mouseEvent) throws IOException {
        clearPane();
        addPane.setStyle("-fx-background-color:#ccfb5d");

        URL resource = getClass().getResource("../view/VehicleAdd.fxml");
        Parent load = FXMLLoader.load(resource);
        vehicleControllerContext.getChildren().add(load);
    }

    public void addVehicleEnteredMouseOnAction(MouseEvent mouseEvent) {
        clearPane();
        new Pulse(addPane).play();
        addPane.setStyle("-fx-background-color: #52D017");
    }

    public void searchMouseOnAction(MouseEvent mouseEvent) throws IOException {
        clearPane();
        searchPane.setStyle("-fx-background-color:#ccfb5d");

        URL resource = getClass().getResource("../view/VehicleSearch.fxml");
        Parent load = FXMLLoader.load(resource);
        vehicleControllerContext.getChildren().add(load);
    }

    public void searchEnteredMouseOnAction(MouseEvent mouseEvent) {
        clearPane();
        new Pulse(searchPane).play();
        searchPane.setStyle("-fx-background-color: #357EC7");
    }

    public void updateVehicleMouseOnAction(MouseEvent mouseEvent) throws IOException {
        clearPane();
        updatePane.setStyle("-fx-background-color:#ccfb5d");

        URL resource = getClass().getResource("../view/VehicleUpdate.fxml");
        Parent load = FXMLLoader.load(resource);
        vehicleControllerContext.getChildren().add(load);
    }

    public void updateVehicleEnteredMouseOnAction(MouseEvent mouseEvent) {
        clearPane();
        new Pulse(updatePane).play();
        updatePane.setStyle("-fx-background-color: #F2BB66");
    }

    public void deleteVehicleMouseOnAction(MouseEvent mouseEvent) throws IOException {
        clearPane();
        deletePane.setStyle("-fx-background-color:#ccfb5d");

        URL resource = getClass().getResource("../view/VehicleDelete.fxml");
        Parent load = FXMLLoader.load(resource);
        vehicleControllerContext.getChildren().add(load);
    }

    public void deleteVehicleMouseEnteredOnAction(MouseEvent mouseEvent) {
        clearPane();
        new Pulse(deletePane).play();
        deletePane.setStyle("-fx-background-color:  #cb6d51");
    }

    public void searchEnterdMouseOnAction(MouseEvent mouseEvent) {
    }




    @Override
    public boolean vehicleAdd(Vehicle v) throws SQLException, ClassNotFoundException {

        Connection con = DbConnection.getInstance().getConnection();
        String query="INSERT INTO vehicle Values(?,?,?,?)";
        PreparedStatement stm = con.prepareStatement(query);
        stm.setObject(1,v.getVehicleId());
        stm.setObject(2,v.getVehicleNumber());
        stm.setObject(3,v.getVehicleType());
        stm.setObject(4,v.getVehicleRent());
        return stm.executeUpdate()>0;
    }

    @Override
    public String getNewVehicleId() throws SQLException, ClassNotFoundException {

            PreparedStatement stm = DbConnection.getInstance().getConnection().
            prepareStatement("SELECT vehicleID FROM vehicle ORDER BY vehicleID DESC LIMIT 1");
            ResultSet resultSet = stm.executeQuery();

            String id = null;
            while (resultSet.next()) {
                String s = resultSet.getString(1);
                int tempId = Integer.parseInt(s.substring(1, 4));
                tempId = ++tempId;

                if (tempId < 10) {
                    id = "V00" + tempId;

                } else if (tempId >= 10 & tempId < 100) {
                    id = "V0" + tempId;
                } else if (tempId > 100) {
                    id = "V" + tempId;
                }


            }
            return id == null ? "V001" : id;


    }

    @Override
    public String getVehicleId() throws SQLException, ClassNotFoundException {
        PreparedStatement stm=DbConnection.getInstance().getConnection().prepareStatement("SELECT vehicleID FROM vehicle ORDER BY vehicleID DESC LIMIT 1");
        ResultSet resultSet = stm.executeQuery();

        return resultSet.getString(1);
    }

    @Override
    public Vehicle searchVehicle(String Id) throws SQLException, ClassNotFoundException {

        PreparedStatement stm = DbConnection.getInstance().getConnection().
                prepareStatement("SELECT * FROM vehicle WHERE vehicleID=?");
        stm.setObject(1,Id);

        ResultSet rst = stm.executeQuery();
        if (rst.next()){
            return new Vehicle(
                    rst.getString(1),
                    rst.getString(2),
                    rst.getString(3),
                    rst.getString(4)
            );
        }else
            return null;
    }

    @Override
    public List<VehicleTm> getVehicle() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM vehicle");
        ResultSet resultSet = stm.executeQuery();
        ArrayList<VehicleTm> vehicleList=new ArrayList();
        while(resultSet.next()){

            vehicleList.add(new VehicleTm(resultSet.getString(1),resultSet.getString(2),
                    resultSet.getString(3),resultSet.getString(4)));

        }

        return vehicleList ;
    }


    @Override
    public boolean vehicleUpdate(Vehicle v) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement
                ("UPDATE vehicle SET vehicleNumber=?, vehicleType=?,  vehicleRent =? WHERE vehicleID=?");
        stm.setObject(1,v.getVehicleNumber());
        stm.setObject(2,v.getVehicleType());
        stm.setObject(3,v.getVehicleRent());
        stm.setObject(4,v.getVehicleId());


        return stm.executeUpdate()>0;

    }

    @Override
    public boolean vehicleDelete(String Id) throws SQLException, ClassNotFoundException {
        if (DbConnection.getInstance().getConnection().prepareStatement
                ("DELETE FROM vehicle WHERE vehicleID='"+Id+"'").executeUpdate()>0){
            return true;
        }else{
            return false;
        }
    }
}
